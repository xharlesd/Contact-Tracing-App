# Contact-Tracing-App
COVID Contact Tracing App using Python GUI
